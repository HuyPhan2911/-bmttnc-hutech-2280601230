from string import ascii_uppercase
ALPHABET = list(ascii_uppercase)